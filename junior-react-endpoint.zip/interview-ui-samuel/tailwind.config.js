const { theme } = require('./src/theme');

module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme,
  plugins: [],
};
